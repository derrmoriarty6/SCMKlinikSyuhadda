-- phpMyAdmin SQL Dump
-- Database: `db_klinik_syuhadda`
-- Sistem Informasi Pengolahan Data Pasien - Klinik Syuhadda

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


CREATE DATABASE IF NOT EXISTS `db_klinik_syuhadda`;
USE `db_klinik_syuhadda`;

-- --------------------------------------------------------
-- Struktur dari tabel `user`
-- --------------------------------------------------------

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nama_lengkap` varchar(50) NOT NULL,
  `level` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `user` (`id_user`, `username`, `password`, `nama_lengkap`, `level`) VALUES
(1, 'admin', 'admin123', 'Administrator Klinik', 'Admin'),
(2, 'operator', 'oper123', 'Operator Pendaftaran', 'Operator');

-- --------------------------------------------------------
-- Struktur dari tabel `tblpasien`
-- --------------------------------------------------------

CREATE TABLE `tblpasien` (
  `no_rm` varchar(10) NOT NULL,
  `nama_pasien` varchar(50) NOT NULL,
  `tmp_lahir` varchar(30) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `usia` int(3) NOT NULL,
  `jenkel` varchar(10) NOT NULL,
  `gol_darah` varchar(5) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `telp` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblpasien` (`no_rm`, `nama_pasien`, `tmp_lahir`, `tgl_lahir`, `usia`, `jenkel`, `gol_darah`, `alamat`, `telp`) VALUES
('RM001', 'Ahmad Rizki', 'Medan', '1990-03-15', 36, 'Laki-Laki', 'A', 'Jl. Sudirman No.10, Medan', '081234567801'),
('RM002', 'Siti Aisyah', 'Binjai', '1985-07-22', 41, 'Perempuan', 'B', 'Jl. Gatot Subroto No.5', '081234567802'),
('RM003', 'Budi Hartono', 'Medan', '1978-11-08', 48, 'Laki-Laki', 'O', 'Jl. Imam Bonjol No.3', '081234567803'),
('RM004', 'Dewi Lestari', 'Tebing Tinggi', '1995-01-30', 31, 'Perempuan', 'AB', 'Jl. Diponegoro No.7', '081234567804'),
('RM005', 'Rudi Saputra', 'Medan', '2000-09-12', 26, 'Laki-Laki', 'A', 'Jl. Pemuda No.15', '081234567805');

-- --------------------------------------------------------
-- Struktur dari tabel `tbldokter`
-- --------------------------------------------------------

CREATE TABLE `tbldokter` (
  `kd_dokter` varchar(10) NOT NULL,
  `nama_dokter` varchar(50) NOT NULL,
  `spesialis` varchar(30) NOT NULL,
  `telp` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbldokter` (`kd_dokter`, `nama_dokter`, `spesialis`, `telp`) VALUES
('DK001', 'dr. Hasan Basri, Sp.PD', 'Penyakit Dalam', '081345678901'),
('DK002', 'dr. Fatimah Zahra, Sp.A', 'Anak', '081345678902'),
('DK003', 'dr. Andi Prasetyo', 'Umum', '081345678903'),
('DK004', 'dr. Rina Sari, Sp.OG', 'Kandungan', '081345678904'),
('DK005', 'dr. Budi Santoso, Sp.B', 'Bedah', '081345678905');

-- --------------------------------------------------------
-- Struktur dari tabel `tblobat`
-- --------------------------------------------------------

CREATE TABLE `tblobat` (
  `kd_obat` varchar(10) NOT NULL,
  `nama_obat` varchar(50) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblobat` (`kd_obat`, `nama_obat`, `harga`) VALUES
('OB001', 'Paracetamol 500mg', 5000),
('OB002', 'Amoxicillin 500mg', 8000),
('OB003', 'Omeprazole 20mg', 12000),
('OB004', 'Antangin Cair', 3000),
('OB005', 'Ibuprofen 400mg', 7000);

-- --------------------------------------------------------
-- Struktur dari tabel `tblrekammedis`
-- --------------------------------------------------------

CREATE TABLE `tblrekammedis` (
  `id_rm` int(11) NOT NULL,
  `tgl_periksa` date NOT NULL,
  `no_rm` varchar(10) NOT NULL,
  `kd_dokter` varchar(10) NOT NULL,
  `kd_obat` varchar(10) NOT NULL,
  `keluhan` varchar(100) NOT NULL,
  `diagnosis` varchar(100) NOT NULL,
  `jml_obat` int(11) NOT NULL,
  `total_biaya` double NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblrekammedis` (`id_rm`, `tgl_periksa`, `no_rm`, `kd_dokter`, `kd_obat`, `keluhan`, `diagnosis`, `jml_obat`, `total_biaya`, `status`) VALUES
(1, '2026-06-01', 'RM001', 'DK003', 'OB001', 'Demam dan sakit kepala', 'Influenza', 3, 15000, 'Rawat Jalan'),
(2, '2026-06-02', 'RM002', 'DK002', 'OB002', 'Batuk berdahak', 'ISPA', 2, 16000, 'Rawat Jalan'),
(3, '2026-06-03', 'RM003', 'DK001', 'OB003', 'Nyeri lambung', 'Gastritis', 3, 36000, 'Rawat Jalan'),
(4, '2026-06-04', 'RM004', 'DK004', 'OB004', 'Mual dan pusing', 'Vertigo', 5, 15000, 'Rawat Jalan'),
(5, '2026-06-05', 'RM005', 'DK005', 'OB005', 'Nyeri perut akut', 'Appendisitis', 2, 14000, 'Dirujuk');

-- --------------------------------------------------------
-- View `queryrekammedis`
-- --------------------------------------------------------

CREATE TABLE `queryrekammedis` (
`id_rm` int(11)
,`tgl_periksa` date
,`no_rm` varchar(10)
,`nama_pasien` varchar(50)
,`tmp_lahir` varchar(30)
,`tgl_lahir` date
,`usia` int(3)
,`jenkel` varchar(10)
,`gol_darah` varchar(5)
,`alamat` varchar(100)
,`telp` varchar(15)
,`kd_dokter` varchar(10)
,`nama_dokter` varchar(50)
,`spesialis` varchar(30)
,`telp_dokter` varchar(15)
,`kd_obat` varchar(10)
,`nama_obat` varchar(50)
,`harga` int(11)
,`keluhan` varchar(100)
,`diagnosis` varchar(100)
,`jml_obat` int(11)
,`total_biaya` double
,`status` varchar(20)
);

DROP TABLE IF EXISTS `queryrekammedis`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `queryrekammedis` AS
SELECT
  `tblrekammedis`.`id_rm` AS `id_rm`,
  `tblrekammedis`.`tgl_periksa` AS `tgl_periksa`,
  `tblrekammedis`.`no_rm` AS `no_rm`,
  `tblpasien`.`nama_pasien` AS `nama_pasien`,
  `tblpasien`.`tmp_lahir` AS `tmp_lahir`,
  `tblpasien`.`tgl_lahir` AS `tgl_lahir`,
  `tblpasien`.`usia` AS `usia`,
  `tblpasien`.`jenkel` AS `jenkel`,
  `tblpasien`.`gol_darah` AS `gol_darah`,
  `tblpasien`.`alamat` AS `alamat`,
  `tblpasien`.`telp` AS `telp`,
  `tblrekammedis`.`kd_dokter` AS `kd_dokter`,
  `tbldokter`.`nama_dokter` AS `nama_dokter`,
  `tbldokter`.`spesialis` AS `spesialis`,
  `tbldokter`.`telp` AS `telp_dokter`,
  `tblrekammedis`.`kd_obat` AS `kd_obat`,
  `tblobat`.`nama_obat` AS `nama_obat`,
  `tblobat`.`harga` AS `harga`,
  `tblrekammedis`.`keluhan` AS `keluhan`,
  `tblrekammedis`.`diagnosis` AS `diagnosis`,
  `tblrekammedis`.`jml_obat` AS `jml_obat`,
  `tblrekammedis`.`total_biaya` AS `total_biaya`,
  `tblrekammedis`.`status` AS `status`
FROM (((`tblrekammedis`
  JOIN `tblpasien`) JOIN `tbldokter`) JOIN `tblobat`)
WHERE ((`tblrekammedis`.`no_rm` = `tblpasien`.`no_rm`)
  AND (`tblrekammedis`.`kd_dokter` = `tbldokter`.`kd_dokter`)
  AND (`tblrekammedis`.`kd_obat` = `tblobat`.`kd_obat`));

-- --------------------------------------------------------
-- Indexes
-- --------------------------------------------------------

ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

ALTER TABLE `tblpasien`
  ADD PRIMARY KEY (`no_rm`);

ALTER TABLE `tbldokter`
  ADD PRIMARY KEY (`kd_dokter`);

ALTER TABLE `tblobat`
  ADD PRIMARY KEY (`kd_obat`);

ALTER TABLE `tblrekammedis`
  ADD PRIMARY KEY (`id_rm`);

-- --------------------------------------------------------
-- AUTO_INCREMENT
-- --------------------------------------------------------

ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `tblrekammedis`
  MODIFY `id_rm` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
