<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class F_MenuUtama
    Inherits System.Windows.Forms.Form
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then components.Dispose()
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub
    Private components As System.ComponentModel.IContainer
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.InputDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PasienToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DokterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ObatToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TransaksiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RekamMedisToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CariDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CariPasienToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CariDokterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CariObatToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LaporanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LaporanRekamMedisToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.KeluarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.lblSubtitle = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(0, 105, 92)
        Me.Panel1.Controls.Add(Me.lblSubtitle)
        Me.Panel1.Controls.Add(Me.lblTitle)
        Me.Panel1.Controls.Add(Me.MenuStrip1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1336, 749)
        Me.MenuStrip1.BackColor = System.Drawing.Color.FromArgb(0, 77, 64)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.InputDataToolStripMenuItem, Me.TransaksiToolStripMenuItem, Me.CariDataToolStripMenuItem, Me.LaporanToolStripMenuItem, Me.KeluarToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1336, 24)
        Me.InputDataToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PasienToolStripMenuItem, Me.DokterToolStripMenuItem, Me.ObatToolStripMenuItem})
        Me.InputDataToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.InputDataToolStripMenuItem.Name = "InputDataToolStripMenuItem"
        Me.InputDataToolStripMenuItem.Size = New System.Drawing.Size(74, 20)
        Me.InputDataToolStripMenuItem.Text = "Input Data"
        Me.PasienToolStripMenuItem.Name = "PasienToolStripMenuItem"
        Me.PasienToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.PasienToolStripMenuItem.Text = "Pasien"
        Me.DokterToolStripMenuItem.Name = "DokterToolStripMenuItem"
        Me.DokterToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.DokterToolStripMenuItem.Text = "Dokter"
        Me.ObatToolStripMenuItem.Name = "ObatToolStripMenuItem"
        Me.ObatToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ObatToolStripMenuItem.Text = "Obat"
        Me.TransaksiToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RekamMedisToolStripMenuItem})
        Me.TransaksiToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.TransaksiToolStripMenuItem.Name = "TransaksiToolStripMenuItem"
        Me.TransaksiToolStripMenuItem.Size = New System.Drawing.Size(66, 20)
        Me.TransaksiToolStripMenuItem.Text = "Transaksi"
        Me.RekamMedisToolStripMenuItem.Name = "RekamMedisToolStripMenuItem"
        Me.RekamMedisToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.RekamMedisToolStripMenuItem.Text = "Rekam Medis"
        Me.CariDataToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CariPasienToolStripMenuItem, Me.CariDokterToolStripMenuItem, Me.CariObatToolStripMenuItem})
        Me.CariDataToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.CariDataToolStripMenuItem.Name = "CariDataToolStripMenuItem"
        Me.CariDataToolStripMenuItem.Size = New System.Drawing.Size(67, 20)
        Me.CariDataToolStripMenuItem.Text = "Cari Data"
        Me.CariPasienToolStripMenuItem.Name = "CariPasienToolStripMenuItem"
        Me.CariPasienToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.CariPasienToolStripMenuItem.Text = "Pasien"
        Me.CariDokterToolStripMenuItem.Name = "CariDokterToolStripMenuItem"
        Me.CariDokterToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.CariDokterToolStripMenuItem.Text = "Dokter"
        Me.CariObatToolStripMenuItem.Name = "CariObatToolStripMenuItem"
        Me.CariObatToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.CariObatToolStripMenuItem.Text = "Obat"
        Me.LaporanToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LaporanRekamMedisToolStripMenuItem})
        Me.LaporanToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.LaporanToolStripMenuItem.Name = "LaporanToolStripMenuItem"
        Me.LaporanToolStripMenuItem.Size = New System.Drawing.Size(62, 20)
        Me.LaporanToolStripMenuItem.Text = "Laporan"
        Me.LaporanRekamMedisToolStripMenuItem.Name = "LaporanRekamMedisToolStripMenuItem"
        Me.LaporanRekamMedisToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.LaporanRekamMedisToolStripMenuItem.Text = "Rekam Medis"
        Me.KeluarToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.KeluarToolStripMenuItem.Name = "KeluarToolStripMenuItem"
        Me.KeluarToolStripMenuItem.Size = New System.Drawing.Size(52, 20)
        Me.KeluarToolStripMenuItem.Text = "Keluar"
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold)
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Location = New System.Drawing.Point(320, 280)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Text = "SISTEM INFORMASI KLINIK SYUHADDA"
        Me.lblSubtitle.AutoSize = True
        Me.lblSubtitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!)
        Me.lblSubtitle.ForeColor = System.Drawing.Color.FromArgb(178, 223, 219)
        Me.lblSubtitle.Location = New System.Drawing.Point(370, 325)
        Me.lblSubtitle.Name = "lblSubtitle"
        Me.lblSubtitle.Text = "Pengolahan Data Pasien - Supply Chain Management"
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1336, 749)
        Me.Controls.Add(Me.Panel1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "F_MenuUtama"
        Me.Text = "Sistem Informasi Klinik Syuhadda"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents InputDataToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PasienToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DokterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ObatToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TransaksiToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RekamMedisToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CariDataToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CariPasienToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CariDokterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CariObatToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LaporanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LaporanRekamMedisToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents KeluarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents lblSubtitle As System.Windows.Forms.Label
End Class
