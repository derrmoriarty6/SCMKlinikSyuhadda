Imports MySql.Data.MySqlClient
Public Class FormObat

    Private Sub caridataobat()
        Dim a As Integer
        Try
            query = "select * From tblobat WHERE kd_obat like '%" & Trim(txtCariData.Text) & "%' or nama_obat like '%" & Trim(txtCariData.Text) & "%' "
            daData = New MySqlDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Isilist()
        Dim a As Integer
        Try
            query = "SELECT * FROM tblobat ORDER BY kd_obat"
            daData = New MySqlDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub posisilist()
        With ListView1.Columns
            .Add("Kode Obat", 100)
            .Add("Nama Obat", 200)
            .Add("Harga (Rp)", 120)
        End With
    End Sub

    Private Sub Bersih()
        txtKdObat.Text = ""
        txtNamaObat.Text = ""
        txtHarga.Text = ""
    End Sub

    Private Sub AmbilDataDariListView()
        With ListView1.SelectedItems
            Try
                txtKdObat.Text = .Item(0).SubItems(0).Text
                txtNamaObat.Text = .Item(0).SubItems(1).Text
                txtHarga.Text = .Item(0).SubItems(2).Text
            Catch ex As Exception
            End Try
        End With
    End Sub

    Private Sub FormObat_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        koneksiKeDataBase()
        posisilist()
        Isilist()
    End Sub

    Private Sub btnRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefresh.Click
        Bersih()
        Isilist()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Try
            If txtKdObat.Text = "" Or txtNamaObat.Text = "" Or txtHarga.Text = "" Then
                MsgBox("Silahkan lengkapi data terlebih dahulu!", MsgBoxStyle.Critical, "Pesan Data Kosong")
                txtKdObat.Focus()
            Else
                query = "Insert Into tblobat Values('" & txtKdObat.Text & "','" & txtNamaObat.Text & "','" & txtHarga.Text & "')"
                daData = New MySqlDataAdapter(query, conn)
                dsData = New DataSet
                daData.Fill(dsData)
                MsgBox("Data berhasil disimpan!", MsgBoxStyle.Information, "SAVE")
                txtKdObat.Focus()
                Isilist()
                Bersih()
            End If
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
            txtKdObat.Focus()
        End Try
    End Sub

    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged
        AmbilDataDariListView()
    End Sub

    Private Sub txtCariData_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCariData.TextChanged
        caridataobat()
    End Sub

    Private Sub btnCariData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariData.Click
        caridataobat()
    End Sub

    Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click
        Try
            If txtKdObat.Text = "" Or txtNamaObat.Text = "" Or txtHarga.Text = "" Then
                MsgBox("Silahkan Pilih Data Yang Akan Di Edit!", MsgBoxStyle.Critical, "Pesan Data Kosong")
                txtKdObat.Focus()
            Else
                query = "UPDATE tblobat SET nama_obat='" & txtNamaObat.Text & "',harga='" & txtHarga.Text & "' WHERE kd_obat='" & txtKdObat.Text & "' "
                daData = New MySqlDataAdapter(query, conn)
                dsData = New DataSet
                daData.Fill(dsData)
                Isilist()
                Bersih()
                txtKdObat.Focus()
                MsgBox("Data Berhasil Di Edit!", MsgBoxStyle.Information, "Edit Data")
            End If
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Try
            Dim A As String
            A = MsgBox("Benar data akan di delete...?", MsgBoxStyle.OkCancel + MsgBoxStyle.Question, "Hapus Data")
            Select Case A
                Case vbCancel
                    txtKdObat.Focus()
                    Exit Sub
                Case vbOK
                    If txtKdObat.Text = "" Then
                        MsgBox("Input Kode Obat Yang Akan Di Hapus", MsgBoxStyle.Critical, "Data Kosong")
                        txtKdObat.Focus()
                    Else
                        query = "DELETE from tblobat WHERE kd_obat='" & txtKdObat.Text & "'"
                        daData = New MySqlDataAdapter(query, conn)
                        dsData = New DataSet
                        daData.Fill(dsData)
                        Isilist()
                        Bersih()
                        MsgBox("Data Berhasil Di Delete", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Hapus Data")
                    End If
            End Select
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Hapus data")
        End Try
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
