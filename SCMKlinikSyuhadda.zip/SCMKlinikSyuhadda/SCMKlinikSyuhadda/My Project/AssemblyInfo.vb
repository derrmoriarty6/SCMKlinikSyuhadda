Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("SCMKlinikSyuhadda")> 
<Assembly: AssemblyDescription("Sistem Informasi Pengolahan Data Pasien - Klinik Syuhadda")> 
<Assembly: AssemblyCompany("Klinik Syuhadda")> 
<Assembly: AssemblyProduct("SCMKlinikSyuhadda")> 
<Assembly: AssemblyCopyright("Copyright ©  2026")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("0bf9c30a-4529-4f95-bf83-12997c64bce6")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
