Imports MySql.Data.MySqlClient
Public Class FormRekamMedis
    Dim hargaobat As Integer
    Dim jumlahobat As Integer
    Dim totalbiaya As Double
    Dim statusPasien As String
    Dim idrm As String

    Private Sub AmbilDataDariListview()
        With ListView1.SelectedItems
            Try
                idrm = .Item(0).SubItems(0).Text
                dtpTglPeriksa.Text = .Item(0).SubItems(1).Text
                txtNoRM.Text = .Item(0).SubItems(2).Text
                txtNamaPasien.Text = .Item(0).SubItems(3).Text
                txtKdDokter.Text = .Item(0).SubItems(4).Text
                txtNamaDokter.Text = .Item(0).SubItems(5).Text
                txtKdObat.Text = .Item(0).SubItems(6).Text
                txtNamaObat.Text = .Item(0).SubItems(7).Text
                txtHarga.Text = .Item(0).SubItems(8).Text
                txtKeluhan.Text = .Item(0).SubItems(9).Text
                txtDiagnosis.Text = .Item(0).SubItems(10).Text
                txtJmlObat.Text = .Item(0).SubItems(11).Text
                txtTotalBiaya.Text = .Item(0).SubItems(12).Text
                txtStatus.Text = .Item(0).SubItems(13).Text
            Catch ex As Exception
            End Try
        End With
    End Sub

    Private Sub posisilist()
        ListView1.Columns.Clear()
        ListView1.View = View.Details
        ListView1.FullRowSelect = True
        ListView1.GridLines = True
        With ListView1.Columns
            .Add("ID", 40)
            .Add("Tgl Periksa", 80)
            .Add("No RM", 60)
            .Add("Nama Pasien", 110)
            .Add("Kd Dokter", 70)
            .Add("Nama Dokter", 120)
            .Add("Kd Obat", 60)
            .Add("Nama Obat", 110)
            .Add("Harga", 70)
            .Add("Keluhan", 120)
            .Add("Diagnosis", 120)
            .Add("Jml Obat", 55)
            .Add("Total Biaya", 80)
            .Add("Status", 90)
        End With
    End Sub

    Private Sub isilist()
        Dim a As Integer
        Try
            query = "Select * From queryrekammedis Order by no_rm"
            daData = New MySqlDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(11))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(12))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(15))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(16))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(17))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(18))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(19))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(20))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(21))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(22))
                End With
            Next
        Catch ex As Exception
            MsgBox("Gagal menampilkan data: " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub prosesbiaya()
        Try
            hargaobat = CInt(txtHarga.Text)
            jumlahobat = CInt(txtJmlObat.Text)
            totalbiaya = hargaobat * jumlahobat
            txtTotalBiaya.Text = totalbiaya

            If txtDiagnosis.Text.ToLower.Contains("appendisitis") Or txtDiagnosis.Text.ToLower.Contains("fraktur") Or txtDiagnosis.Text.ToLower.Contains("tumor") Or txtDiagnosis.Text.ToLower.Contains("kanker") Or txtDiagnosis.Text.ToLower.Contains("operasi") Then
                statusPasien = "Dirujuk"
            Else
                statusPasien = "Rawat Jalan"
            End If
            txtStatus.Text = statusPasien
        Catch ex As Exception
            MsgBox("Pastikan harga dan jumlah obat berupa angka!", MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub BtnCariPasien_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCariPasien.Click
        FormCariPasien.Show()
    End Sub

    Private Sub BtnCariDokter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCariDokter.Click
        FormCariDokter.Show()
    End Sub

    Private Sub BtnCariObat_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariObat.Click
        FormCariObat.Show()
    End Sub

    Private Sub BtnProses_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnProses.Click
        prosesbiaya()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Try
            If txtNoRM.Text = "" Or txtKdDokter.Text = "" Or txtKdObat.Text = "" Or txtKeluhan.Text = "" Or txtDiagnosis.Text = "" Or txtJmlObat.Text = "" Or txtTotalBiaya.Text = "" Or txtStatus.Text = "" Then
                MsgBox("Silahkan lengkapi data terlebih dahulu!", MsgBoxStyle.Critical, "Pesan Data Kosong")
            Else
                Call KoneksiKeDatabase()
                Query = "insert into tblrekammedis(tgl_periksa,no_rm,kd_dokter,kd_obat,keluhan,diagnosis,jml_obat,total_biaya,status) values ('" & Format(dtpTglPeriksa.Value, "yyyy/MM/dd") & "','" & txtNoRM.Text & "','" & txtKdDokter.Text & "','" & txtKdObat.Text & "','" & txtKeluhan.Text & "','" & txtDiagnosis.Text & "','" & txtJmlObat.Text & "','" & txtTotalBiaya.Text & "','" & txtStatus.Text & "')"
                daData = New MySqlDataAdapter(Query, Conn)
                dsData = New DataSet
                daData.Fill(dsData)
                MsgBox("Data berhasil disimpan!", MsgBoxStyle.Information, "SAVE")
                isilist()
                bersihkandata()
            End If
        Catch ex As Exception
            MsgBox("Error: " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub FormRekamMedis_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        koneksiKeDataBase()
        posisilist()
        isilist()
    End Sub

    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged
        AmbilDataDariListview()
    End Sub

    Private Sub bersihkandata()
        txtNoRM.Text = "" : txtNamaPasien.Text = ""
        txtKdDokter.Text = "" : txtNamaDokter.Text = ""
        txtKdObat.Text = "" : txtNamaObat.Text = "" : txtHarga.Text = ""
        txtKeluhan.Text = "" : txtDiagnosis.Text = ""
        txtJmlObat.Text = "" : txtTotalBiaya.Text = "" : txtStatus.Text = ""
    End Sub

    Private Sub btnRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefresh.Click
        bersihkandata()
        isilist()
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click
        Try
            If txtNoRM.Text = "" Or txtKdDokter.Text = "" Or txtKdObat.Text = "" Or txtTotalBiaya.Text = "" Then
                MsgBox("Lengkapi data yang akan diedit", MsgBoxStyle.Critical, "Pesan Kosong")
            Else
                query = "Update tblrekammedis set tgl_periksa='" & Format(dtpTglPeriksa.Value, "yyyy/MM/dd") & "',no_rm='" & txtNoRM.Text & "',kd_dokter='" & txtKdDokter.Text & "',kd_obat='" & txtKdObat.Text & "',keluhan='" & txtKeluhan.Text & "',diagnosis='" & txtDiagnosis.Text & "',jml_obat='" & txtJmlObat.Text & "',total_biaya='" & txtTotalBiaya.Text & "',status='" & txtStatus.Text & "' where id_rm='" & idrm & "'"
                daData = New MySqlDataAdapter(query, conn)
                dsData = New DataSet
                daData.Fill(dsData)
                MsgBox("Data berhasil di edit!", MsgBoxStyle.Information, "Edit")
                isilist()
                bersihkandata()
            End If
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Try
            Dim A As String
            A = MsgBox("Benar data akan di delete...?", MsgBoxStyle.OkCancel + MsgBoxStyle.Question, "Hapus Data")
            Select Case A
                Case vbCancel
                    Exit Sub
                Case vbOK
                    query = "DELETE from tblrekammedis WHERE id_rm='" & idrm & "'"
                    daData = New MySqlDataAdapter(query, conn)
                    dsData = New DataSet
                    daData.Fill(dsData)
                    isilist()
                    bersihkandata()
                    MsgBox("Data Berhasil Di Delete", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Hapus Data")
            End Select
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub
End Class
