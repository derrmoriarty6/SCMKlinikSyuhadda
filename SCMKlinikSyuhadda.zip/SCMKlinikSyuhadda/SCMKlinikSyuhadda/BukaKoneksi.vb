Imports MySql.Data.MySqlClient

Module bukakoneksi
    Public conn As MySqlConnection
    Public daData As MySqlDataAdapter
    Public dsData As DataSet
    Public query As String
    Public RD As MySqlDataReader
    Public cmd As MySqlCommand

    Public Sub koneksiKeDataBase()
        Try
            Dim str As String = "server=localhost;user id=root;password=;database=db_klinik_syuhadda"
            conn = New MySqlConnection(str)

            If conn.State = ConnectionState.Closed Then
                conn.Open()
            End If

        Catch ex As Exception
            MsgBox("Koneksi ke server gagal! " & vbCrLf & ex.Message, MsgBoxStyle.Critical, "Error Koneksi")
        End Try
    End Sub
End Module
