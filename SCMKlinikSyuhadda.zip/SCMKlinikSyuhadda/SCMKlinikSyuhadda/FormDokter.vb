Imports MySql.Data.MySqlClient
Public Class FormDokter

    Private Sub caridatadokter()
        Dim a As Integer
        Try
            Query = "SELECT * FROM tbldokter WHERE kd_dokter like '%" & Trim(txtCariData.Text) & "%' or nama_dokter like '%" & Trim(txtCariData.Text) & "%' "
            daData = New MySqlDataAdapter(Query, Conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub AmbilDataDariListview()
        With Listview1.SelectedItems
            Try
                txtKdDokter.Text = .Item(0).SubItems(0).Text
                txtNamaDokter.Text = .Item(0).SubItems(1).Text
                txtSpesialis.Text = .Item(0).SubItems(2).Text
                txtTelp.Text = .Item(0).SubItems(3).Text
            Catch ex As Exception
            End Try
        End With
    End Sub

    Private Sub Posisilist()
        With ListView1.Columns
            .Add("Kode Dokter", 100)
            .Add("Nama Dokter", 180)
            .Add("Spesialis", 140)
            .Add("Telepon", 120)
        End With
    End Sub

    Private Sub Isilist()
        Dim a As Integer
        Try
            Query = "SELECT * FROM tbldokter ORDER BY kd_dokter"
            daData = New MySqlDataAdapter(Query, Conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub bersih()
        txtKdDokter.Text = ""
        txtNamaDokter.Text = ""
        txtSpesialis.Text = ""
        txtTelp.Text = ""
    End Sub

    Private Sub FormDokter_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        KoneksiKeDatabase()
        Posisilist()
        Isilist()
    End Sub

    Private Sub btnRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefresh.Click
        bersih()
        Isilist()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Try
            If txtKdDokter.Text = "" Or txtNamaDokter.Text = "" Or txtSpesialis.Text = "" Or txtTelp.Text = "" Then
                MsgBox("Silahkan lengkapi data terlebih dahulu!", MsgBoxStyle.Critical, "Pesan Data Kosong")
                txtKdDokter.Focus()
            Else
                Query = "INSERT INTO tbldokter VALUES('" & txtKdDokter.Text & "','" & txtNamaDokter.Text & "','" & txtSpesialis.Text & "','" & txtTelp.Text & "')"
                daData = New MySqlDataAdapter(Query, Conn)
                dsData = New DataSet
                daData.Fill(dsData)
                MsgBox("Data berhasil disimpan!", MsgBoxStyle.Information, "SAVE")
                txtKdDokter.Focus()
                Isilist()
                bersih()
            End If
        Catch ex As Exception
            MsgBox("Kode Dokter ini sudah ada!", MsgBoxStyle.Exclamation, "Error")
            txtKdDokter.Focus()
        End Try
    End Sub

    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged
        AmbilDataDariListview()
    End Sub

    Private Sub txtCariData_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCariData.TextChanged
        caridatadokter()
    End Sub

    Private Sub btnCariData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariData.Click
        caridatadokter()
    End Sub

    Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click
        Try
            If txtKdDokter.Text = "" Or txtNamaDokter.Text = "" Or txtSpesialis.Text = "" Or txtTelp.Text = "" Then
                MsgBox("Silahkan Pilih Data Yang Akan Di Edit!", MsgBoxStyle.Critical, "Pesan Data Kosong")
                txtKdDokter.Focus()
            Else
                Query = "UPDATE tbldokter SET nama_dokter='" & txtNamaDokter.Text & "',spesialis='" & txtSpesialis.Text & "', telp='" & txtTelp.Text & "' WHERE kd_dokter='" & txtKdDokter.Text & "' "
                daData = New MySqlDataAdapter(Query, Conn)
                dsData = New DataSet
                daData.Fill(dsData)
                Isilist()
                bersih()
                txtKdDokter.Focus()
                MsgBox("Data Berhasil Di Edit!", MsgBoxStyle.Information, "Edit Data")
            End If
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Try
            Dim A As String
            A = MsgBox("Benar data akan di delete...?", MsgBoxStyle.OkCancel + MsgBoxStyle.Question, "Hapus Data")
            Select Case A
                Case vbCancel
                    txtKdDokter.Focus()
                    Exit Sub
                Case vbOK
                    If txtKdDokter.Text = "" Then
                        MsgBox("Input Kode Dokter Yang Akan Di Hapus", MsgBoxStyle.Critical, "Data Kosong")
                        txtKdDokter.Focus()
                    Else
                        Query = "DELETE from tbldokter WHERE kd_dokter='" & txtKdDokter.Text & "'"
                        daData = New MySqlDataAdapter(Query, Conn)
                        dsData = New DataSet
                        daData.Fill(dsData)
                        Isilist()
                        bersih()
                        MsgBox("Data Berhasil Di Delete", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Hapus Data")
                    End If
            End Select
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Hapus data")
        End Try
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
