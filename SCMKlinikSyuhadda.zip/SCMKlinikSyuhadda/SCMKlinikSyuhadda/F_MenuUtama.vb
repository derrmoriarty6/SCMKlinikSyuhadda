Public Class F_MenuUtama
    Private Sub PasienToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PasienToolStripMenuItem.Click
        FormPasien.ShowDialog()
    End Sub
    Private Sub DokterToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DokterToolStripMenuItem.Click
        FormDokter.ShowDialog()
    End Sub
    Private Sub ObatToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ObatToolStripMenuItem.Click
        FormObat.ShowDialog()
    End Sub
    Private Sub RekamMedisToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RekamMedisToolStripMenuItem.Click
        FormRekamMedis.ShowDialog()
    End Sub
    Private Sub CariPasienToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CariPasienToolStripMenuItem.Click
        FormCariPasien.ShowDialog()
    End Sub
    Private Sub CariDokterToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CariDokterToolStripMenuItem.Click
        FormCariDokter.ShowDialog()
    End Sub
    Private Sub CariObatToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CariObatToolStripMenuItem.Click
        FormCariObat.ShowDialog()
    End Sub
    Private Sub LaporanRekamMedisToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LaporanRekamMedisToolStripMenuItem.Click
        FormLaporan.ShowDialog()
    End Sub
    Private Sub KeluarToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KeluarToolStripMenuItem.Click
        End
    End Sub
End Class
