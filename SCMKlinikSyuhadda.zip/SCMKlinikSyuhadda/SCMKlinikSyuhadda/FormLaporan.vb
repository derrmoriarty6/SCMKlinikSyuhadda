Imports MySql.Data.MySqlClient
Imports System.Drawing.Printing
Public Class FormLaporan
    Private printDoc As New PrintDocument()
    Private printData As New List(Of String())

    Private Sub Posisilist()
        With ListView1.Columns
            .Add("ID", 40)
            .Add("Tgl Periksa", 80)
            .Add("No RM", 60)
            .Add("Nama Pasien", 110)
            .Add("Nama Dokter", 120)
            .Add("Nama Obat", 110)
            .Add("Keluhan", 120)
            .Add("Diagnosis", 120)
            .Add("Jml", 40)
            .Add("Total Biaya", 80)
            .Add("Status", 80)
        End With
    End Sub

    Private Sub Isilist()
        Dim a As Integer
        Try
            Query = "Select * From queryrekammedis Order by id_rm"
            daData = New MySqlDataAdapter(Query, Conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            printData.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(12))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(16))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(18))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(19))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(20))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(21))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(22))
                End With
                Dim row() As String = {dsData.Tables(0).Rows(a).Item(0).ToString, dsData.Tables(0).Rows(a).Item(1).ToString, dsData.Tables(0).Rows(a).Item(2).ToString, dsData.Tables(0).Rows(a).Item(3).ToString, dsData.Tables(0).Rows(a).Item(12).ToString, dsData.Tables(0).Rows(a).Item(16).ToString, dsData.Tables(0).Rows(a).Item(18).ToString, dsData.Tables(0).Rows(a).Item(19).ToString, dsData.Tables(0).Rows(a).Item(20).ToString, dsData.Tables(0).Rows(a).Item(21).ToString, dsData.Tables(0).Rows(a).Item(22).ToString}
                printData.Add(row)
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub caridatalaporan()
        Dim a As Integer
        Try
            Query = "Select * From queryrekammedis WHERE no_rm like '%" & Trim(txtCariData.Text) & "%' or nama_pasien like '%" & Trim(txtCariData.Text) & "%' Order by id_rm"
            daData = New MySqlDataAdapter(Query, Conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            printData.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(12))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(16))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(18))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(19))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(20))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(21))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(22))
                End With
                Dim row() As String = {dsData.Tables(0).Rows(a).Item(0).ToString, dsData.Tables(0).Rows(a).Item(1).ToString, dsData.Tables(0).Rows(a).Item(2).ToString, dsData.Tables(0).Rows(a).Item(3).ToString, dsData.Tables(0).Rows(a).Item(12).ToString, dsData.Tables(0).Rows(a).Item(16).ToString, dsData.Tables(0).Rows(a).Item(18).ToString, dsData.Tables(0).Rows(a).Item(19).ToString, dsData.Tables(0).Rows(a).Item(20).ToString, dsData.Tables(0).Rows(a).Item(21).ToString, dsData.Tables(0).Rows(a).Item(22).ToString}
                printData.Add(row)
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub FormLaporan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        KoneksiKeDatabase()
        Posisilist()
        Isilist()
        AddHandler printDoc.PrintPage, AddressOf printDoc_PrintPage
    End Sub

    Private Sub txtCariData_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCariData.TextChanged
        caridatalaporan()
    End Sub

    Private Sub btnCariData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariData.Click
        caridatalaporan()
    End Sub

    Private Sub btnCetak_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCetak.Click
        Try
            printDoc.DefaultPageSettings.Landscape = True
            Dim ppd As New PrintPreviewDialog()
            ppd.Document = printDoc
            ppd.Width = 1000
            ppd.Height = 600
            ppd.ShowDialog()
        Catch ex As Exception
            MsgBox("Error cetak: " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub printDoc_PrintPage(ByVal sender As Object, ByVal e As PrintPageEventArgs)
        Dim fontTitle As New Font("Microsoft Sans Serif", 14, FontStyle.Bold)
        Dim fontSubtitle As New Font("Microsoft Sans Serif", 10)
        Dim fontHeader As New Font("Microsoft Sans Serif", 8, FontStyle.Bold)
        Dim fontBody As New Font("Microsoft Sans Serif", 7)
        Dim y As Integer = 30

        Dim sf As New StringFormat()
        sf.Trimming = StringTrimming.EllipsisCharacter
        sf.FormatFlags = StringFormatFlags.NoWrap

        e.Graphics.DrawString("KLINIK SYUHADDA", fontTitle, Brushes.Black, 450, y)
        y += 25
        e.Graphics.DrawString("Laporan Rekam Medis Pasien", fontSubtitle, Brushes.Black, 440, y)
        y += 20
        e.Graphics.DrawString("Tanggal Cetak: " & Now.ToString("dd/MM/yyyy"), fontBody, Brushes.Black, 30, y)
        y += 25
        e.Graphics.DrawLine(Pens.Black, 30, y, 1050, y)
        y += 5

        Dim headers() As String = {"ID", "Tgl Periksa", "No RM", "Nama Pasien", "Dokter", "Obat", "Keluhan", "Diagnosis", "Jml", "Total", "Status"}
        Dim xPos() As Integer = {30, 60, 130, 190, 320, 470, 600, 750, 870, 910, 980}
        Dim colWidths() As Integer = {30, 70, 60, 130, 150, 130, 150, 120, 40, 70, 70}

        For i = 0 To headers.Length - 1
            Dim rect As New RectangleF(xPos(i), y, colWidths(i), 20)
            e.Graphics.DrawString(headers(i), fontHeader, Brushes.Black, rect, sf)
        Next
        y += 18
        e.Graphics.DrawLine(Pens.Black, 30, y, 1050, y)
        y += 5

        For Each row As String() In printData
            ' Format tgl periksa agar rapi, ambil 10 karakter pertama (yyyy-MM-dd)
            Dim tgl As String = row(1)
            If tgl.Length > 10 Then tgl = tgl.Substring(0, 10)

            Dim rowData() As String = {row(0), tgl, row(2), row(3), row(4), row(5), row(6), row(7), row(8), row(9), row(10)}

            For i = 0 To rowData.Length - 1
                Dim rect As New RectangleF(xPos(i), y, colWidths(i), 15)
                e.Graphics.DrawString(rowData(i), fontBody, Brushes.Black, rect, sf)
            Next
            y += 15
            ' Batas margin bawah untuk mode Landscape
            If y > 750 Then Exit For
        Next

        y += 10
        e.Graphics.DrawLine(Pens.Black, 30, y, 1050, y)
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
