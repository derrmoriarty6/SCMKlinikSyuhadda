Imports MySql.Data.MySqlClient
Public Class FormCariObat
    Private Sub Posisilist()
        With ListView1.Columns
            .Add("Kode Obat", 100)
            .Add("Nama Obat", 200)
            .Add("Harga (Rp)", 120)
        End With
    End Sub
    Private Sub Isilist()
        Dim a As Integer
        Try
            Query = "SELECT * FROM tblobat ORDER BY kd_obat"
            daData = New MySqlDataAdapter(Query, Conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub
    Private Sub caridataobat()
        Dim a As Integer
        Try
            Query = "SELECT * FROM tblobat WHERE kd_obat like '%" & Trim(txtCariData.Text) & "%' or nama_obat like '%" & Trim(txtCariData.Text) & "%' "
            daData = New MySqlDataAdapter(Query, Conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub
    Private Sub AmbilDataDariListview()
        With Listview1.SelectedItems
            Try
                FormRekamMedis.txtKdObat.Text = .Item(0).SubItems(0).Text
                FormRekamMedis.txtNamaObat.Text = .Item(0).SubItems(1).Text
                FormRekamMedis.txtHarga.Text = .Item(0).SubItems(2).Text
            Catch ex As Exception
            End Try
        End With
    End Sub
    Private Sub FormCariObat_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        KoneksiKeDatabase()
        Posisilist()
        Isilist()
    End Sub
    Private Sub txtCariData_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCariData.TextChanged
        caridataobat()
    End Sub
    Private Sub btnCariData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariData.Click
        caridataobat()
    End Sub
    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged
        AmbilDataDariListview()
        Me.Close()
    End Sub
End Class
