Imports MySql.Data.MySqlClient
Public Class FormCariPasien
    Private Sub Posisilist()
        With ListView1.Columns
            .Add("No RM", 70)
            .Add("Nama Pasien", 120)
            .Add("Tempat Lahir", 100)
            .Add("Tgl Lahir", 80)
            .Add("Usia", 40)
            .Add("Jenis Kelamin", 80)
            .Add("Gol Darah", 60)
            .Add("Alamat", 150)
            .Add("Telp", 90)
        End With
    End Sub
    Private Sub Isilist()
        Dim a As Integer
        Try
            Query = "SELECT * FROM tblpasien ORDER BY no_rm"
            daData = New MySqlDataAdapter(Query, Conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(6))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(7))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(8))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub
    Private Sub caridatapasien()
        Dim a As Integer
        Try
            Query = "SELECT * FROM tblpasien WHERE no_rm like '%" & Trim(txtCariData.Text) & "%' or nama_pasien like '%" & Trim(txtCariData.Text) & "%' "
            daData = New MySqlDataAdapter(Query, Conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(6))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(7))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(8))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub
    Private Sub AmbilDataDariListview()
        With Listview1.SelectedItems
            Try
                FormRekamMedis.txtNoRM.Text = .Item(0).SubItems(0).Text
                FormRekamMedis.txtNamaPasien.Text = .Item(0).SubItems(1).Text
            Catch ex As Exception
            End Try
        End With
    End Sub
    Private Sub FormCariPasien_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        KoneksiKeDatabase()
        Posisilist()
        Isilist()
    End Sub
    Private Sub txtCariData_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCariData.TextChanged
        caridatapasien()
    End Sub
    Private Sub btnCariData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariData.Click
        caridatapasien()
    End Sub
    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged
        AmbilDataDariListview()
        Me.Close()
    End Sub
End Class
