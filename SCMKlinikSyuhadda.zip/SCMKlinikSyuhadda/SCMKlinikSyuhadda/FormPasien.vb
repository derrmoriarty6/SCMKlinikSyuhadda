Imports MySql.Data.MySqlClient
Public Class FormPasien
    Dim goldarah As String
    Dim a As MsgBoxResult

    Private Sub posisilist()
        With ListView1.Columns
            .Add("No RM", 60)
            .Add("Nama Pasien", 110)
            .Add("Tempat Lahir", 90)
            .Add("Tgl Lahir", 80)
            .Add("Usia", 40)
            .Add("Jenis Kelamin", 80)
            .Add("Gol Darah", 55)
            .Add("Alamat", 150)
            .Add("Telp/Hp", 90)
        End With
    End Sub

    Private Sub Isilist()
        Dim a As Integer
        Try
            query = "SELECT * FROM tblpasien ORDER BY no_rm"
            daData = New MySqlDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(6))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(7))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(8))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub caridatapasien()
        Dim a As Integer
        Try
            query = "select * From tblpasien WHERE no_rm like '%" & Trim(txtCariData.Text) & "%' or nama_pasien like '%" & Trim(txtCariData.Text) & "%' "
            daData = New MySqlDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(6))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(7))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(8))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub AmbilDataDariListView()
        With ListView1.SelectedItems
            Try
                txtNoRM.Text = .Item(0).SubItems(0).Text
                txtNamaPasien.Text = .Item(0).SubItems(1).Text
                txtTmpLahir.Text = .Item(0).SubItems(2).Text
                dtpTglLahir.Text = .Item(0).SubItems(3).Text
                txtUsia.Text = .Item(0).SubItems(4).Text
                Dim jenkel As String
                jenkel = .Item(0).SubItems(5).Text
                If jenkel = "Laki-Laki" Then
                    rdbLaki.Checked = True
                ElseIf jenkel = "Perempuan" Then
                    rdbPerempuan.Checked = True
                End If
                Dim gd As String
                gd = .Item(0).SubItems(6).Text
                cbA.Checked = False : cbB.Checked = False : cbAB.Checked = False : cbO.Checked = False
                If gd = "A" Then cbA.Checked = True
                If gd = "B" Then cbB.Checked = True
                If gd = "AB" Then cbAB.Checked = True
                If gd = "O" Then cbO.Checked = True
                txtAlamat.Text = .Item(0).SubItems(7).Text
                txtTelp.Text = .Item(0).SubItems(8).Text
            Catch ex As Exception
            End Try
        End With
    End Sub

    Private Sub FormPasien_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Call koneksiKeDataBase()
            Call posisilist()
            Call Isilist()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub dtpTglLahir_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpTglLahir.ValueChanged
        HitungUsia()
    End Sub

    Private Sub HitungUsia()
        Dim thn As Integer
        thn = Year(Now) - Year(dtpTglLahir.Value)
        txtUsia.Text = thn
    End Sub

    Private Sub cbA_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbA.CheckedChanged
        If cbA.Checked Then
            cbB.Checked = False : cbAB.Checked = False : cbO.Checked = False
            goldarah = "A"
        End If
    End Sub
    Private Sub cbB_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbB.CheckedChanged
        If cbB.Checked Then
            cbA.Checked = False : cbAB.Checked = False : cbO.Checked = False
            goldarah = "B"
        End If
    End Sub
    Private Sub cbAB_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbAB.CheckedChanged
        If cbAB.Checked Then
            cbA.Checked = False : cbB.Checked = False : cbO.Checked = False
            goldarah = "AB"
        End If
    End Sub
    Private Sub cbO_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbO.CheckedChanged
        If cbO.Checked Then
            cbA.Checked = False : cbB.Checked = False : cbAB.Checked = False
            goldarah = "O"
        End If
    End Sub

    Private Sub Bersih()
        txtNoRM.Text = ""
        txtNamaPasien.Text = ""
        txtTmpLahir.Text = ""
        txtUsia.Text = ""
        rdbLaki.Checked = False
        rdbPerempuan.Checked = False
        cbA.Checked = False : cbB.Checked = False : cbAB.Checked = False : cbO.Checked = False
        txtAlamat.Text = ""
        txtTelp.Text = ""
    End Sub

    Private Sub btnRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefresh.Click
        Bersih()
        Isilist()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Try
            Dim jenkel As String
            If rdbLaki.Checked = True Then
                jenkel = "Laki-Laki"
            Else
                jenkel = "Perempuan"
            End If
            If txtNoRM.Text = "" Or txtNamaPasien.Text = "" Or txtTmpLahir.Text = "" Or txtUsia.Text = "" Or txtAlamat.Text = "" Then
                MsgBox("Silahkan lengkapi data terlebih dahulu!", MsgBoxStyle.Critical, "Pesan Data Kosong")
                txtNoRM.Focus()
            Else
                query = "Insert Into tblpasien Values('" & txtNoRM.Text & "','" & txtNamaPasien.Text & "','" & txtTmpLahir.Text & "','" & Format(dtpTglLahir.Value, "yyyy/MM/dd") & "','" & txtUsia.Text & "','" & jenkel & "','" & goldarah & "','" & txtAlamat.Text & "','" & txtTelp.Text & "')"
                daData = New MySqlDataAdapter(query, conn)
                dsData = New DataSet
                daData.Fill(dsData)
                MsgBox("Data berhasil disimpan!", MsgBoxStyle.Information, "SAVE")
                txtNoRM.Focus()
                Isilist()
                Bersih()
            End If
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
            txtNoRM.Focus()
        End Try
    End Sub

    Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click
        Try
            Dim jenkel As String
            If rdbLaki.Checked = True Then
                jenkel = "Laki-Laki"
            Else
                jenkel = "Perempuan"
            End If
            If txtNoRM.Text = "" Or txtNamaPasien.Text = "" Or txtTmpLahir.Text = "" Or txtUsia.Text = "" Or txtAlamat.Text = "" Or txtTelp.Text = "" Then
                MsgBox("Silahkan Pilih Data Yang Akan Di Edit!", MsgBoxStyle.Critical, "Pesan Data Kosong")
                txtNoRM.Focus()
            Else
                query = "UPDATE tblpasien SET nama_pasien='" & txtNamaPasien.Text & "',tmp_lahir='" & txtTmpLahir.Text & "',tgl_lahir='" & Format(dtpTglLahir.Value, "yyyy/MM/dd") & "',usia='" & txtUsia.Text & "',jenkel='" & jenkel & "',gol_darah='" & goldarah & "',alamat='" & txtAlamat.Text & "',telp='" & txtTelp.Text & "' WHERE no_rm='" & txtNoRM.Text & "'"
                daData = New MySqlDataAdapter(query, conn)
                dsData = New DataSet
                daData.Fill(dsData)
                Isilist()
                Bersih()
                txtNoRM.Focus()
                MsgBox("Data Berhasil Di Edit!", MsgBoxStyle.Information, "Edit Data")
            End If
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged
        AmbilDataDariListView()
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Try
            a = MsgBox("Benar data akan Di Delete ...?", MsgBoxStyle.OkCancel + MsgBoxStyle.Question, "Hapus Data")
            Select Case a
                Case vbCancel
                    txtNoRM.Focus()
                    Exit Sub
                Case vbOK
                    If txtNoRM.Text = "" Then
                        MsgBox("Input No RM yang akan di hapus", MsgBoxStyle.Critical, "Data Kosong")
                    Else
                        query = "Delete From tblpasien Where no_rm='" & txtNoRM.Text & "'"
                        daData = New MySqlDataAdapter(query, conn)
                        dsData = New DataSet
                        daData.Fill(dsData)
                        Isilist()
                        Bersih()
                        MsgBox("Data berhasil di delete!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Hapus Data")
                    End If
            End Select
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Hapus data")
        End Try
    End Sub

    Private Sub txtCariData_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCariData.TextChanged
        caridatapasien()
    End Sub

    Private Sub btnCariData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariData.Click
        caridatapasien()
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
